import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dd',
  templateUrl: './dd.component.html',
  styleUrls: ['./dd.component.scss']
})
export class DdComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
