import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reusables',
  templateUrl: './reusables.component.html',
  styleUrls: ['./reusables.component.scss']
})
export class ReusablesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
