export class Menu {
    url: string;
    displayName: string;
    id: number;
}